from django.contrib import admin
from .models import inserting

# Register your models here.

admin.site.register(inserting)
