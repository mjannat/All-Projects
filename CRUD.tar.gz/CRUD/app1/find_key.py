def convert(str):
    #for i in range(str):
    pass
        